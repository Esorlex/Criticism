import os,cv2
b=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
f=os.path.join(b,"info","camera")
os.makedirs(f,exist_ok=True)
c=cv2.VideoCapture(0,cv2.CAP_MSMF)
if c.isOpened():
 r,fr=c.read()
 if r: cv2.imwrite(os.path.join(f,"camera0.png"),fr)
c.release()
cv2.destroyAllWindows()
